﻿namespace CompanyEmployees.Entities.DataTransferObjects
{
    public class ForgotPasswordDto
    {
        public string? Email { get; set; }
    }
}
