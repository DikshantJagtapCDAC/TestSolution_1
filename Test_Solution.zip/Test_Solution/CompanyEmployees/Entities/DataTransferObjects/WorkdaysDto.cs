﻿namespace CompanyEmployees.Entities.DataTransferObjects
{
    public class WorkdaysDto
    {
        public int Workdays { get; set; }
    }
}
